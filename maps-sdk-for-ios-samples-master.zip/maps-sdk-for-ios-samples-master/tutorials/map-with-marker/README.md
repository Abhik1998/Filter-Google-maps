Google Maps SDK for iOS Sample: Adding a Map with a Marker
==========================================================

This sample goes hand in hand with a tutorial for the Google Maps SDK for iOS:
[Adding a Map with a Marker](https://developers.google.com/maps/documentation/ios-sdk/map-with-marker).
Follow the tutorial for a quick guide to using the SDK.

License
-------

Please refer to the [LICENSE](https://github.com/googlemaps/maps-sdk-for-ios-samples/blob/master/LICENSE.txt) 
at the root of this repo.
