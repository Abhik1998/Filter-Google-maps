Google Places API for iOS Sample: Address Form Autocomplete
==========================================================

This sample goes hand in hand with a tutorial for the Google Places API for iOS:
[Address Form Autocomplete](https://developers.google.com/places/ios-api/address-form-tutorial).
Follow the tutorial for a quick guide to using the API.

License
-------

Please refer to the [LICENSE](https://github.com/googlemaps/maps-sdk-for-ios-samples/blob/master/LICENSE.txt) 
at the root of this repo.
