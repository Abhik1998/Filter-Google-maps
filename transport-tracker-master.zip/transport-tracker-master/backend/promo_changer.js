/*
 * Copyright 2017 Google Inc. All rights reserved.
 *
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this
 * file except in compliance with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
 * ANY KIND, either express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

const promos = [
  {
    html: 'Bus locations powered by <span style="font-weight: 500;">fused location provider</span> on Android',
    product: 'android'
  },
  {
    html: 'Predicted travel times from the <span style="font-weight: 500;">Google Maps Directions API</span>',
    product: 'google-maps'
  },
  {
    html: 'Locations snapped to the road with the <span style="font-weight: 500;">Google Maps Roads API</span>',
    product: 'google-maps'
  },
  {
    html: 'Styled map with the <span style="font-weight: 500;">Google Maps JavaScript API</span> showing routes and schedules',
    product: 'google-maps'
  },
  {
    html: 'Data synchronized in real time with <span style="font-weight: 500;">Firebase Realtime Database</span>',
    product: 'firebase'
  },
  {
    html: '<span style="font-weight: 500;">Node.js</span> and <span style="font-weight: 500;">Google Compute Engine</span> for backend processing',
    product: 'gce'
  }
];

exports.PromoChanger = class {
  constructor(promoRef) {
    this.promoRef = promoRef;
    this.promoIndex = 0;

    // Change the promo once every five seconds
    this.timeTimerId = setInterval(() => {
      this.promoAdvance();
    }, 10000);
  }

  promoAdvance() {
    const promo = promos[this.promoIndex];
    promo.position = this.promoIndex + 1;
    promo.totalCount = promos.length;
    this.promoRef.set(promo);
    this.promoIndex = (this.promoIndex + 1) % promos.length;
  }
};
