cp continents-local.py /Library/WebServer/CGI-Executables
