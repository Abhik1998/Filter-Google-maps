#import <UIKit/UIKit.h>

@class HMViewController;

@interface HMAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) HMViewController *viewController;

@end
