#import <UIKit/UIKit.h>
#import <GoogleMaps/GoogleMaps.h>

@interface HMSBViewController : UIViewController
@property (weak, nonatomic) IBOutlet GMSMapView *mapView;
@end
